/usr/share/mpss/test/memkind-dt/all_tests -a --gtest_filter=-PerformanceTest.*:*.*ext*
/usr/share/mpss/test/memkind-dt/decorator_test -a
/usr/share/mpss/test/memkind-dt/gb_page_tests_bind_policy -a --gtest_filter=-*.*ext*
/usr/share/mpss/test/memkind-dt/gb_page_tests_bind_policy -a --gtest_filter=-*.*ext*
